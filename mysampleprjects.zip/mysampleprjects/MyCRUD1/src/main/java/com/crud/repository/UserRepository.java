package com.crud.repository;

import com.crud.entity.User;
import org.springframework.data.repository.CrudRepository;



public interface UserRepository extends CrudRepository<User, Integer> {

    User findById(int id);
   //User delete(int id);

}
