package com.kdreammusic.controller

import com.kdreammusic.service.CategoryService
import org.springframework.beans.factory.annotation.Autowired
import com.kdreammusic.model.Category
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController

@RestController
class CategoryController {

    @Autowired
    private CategoryService categoryService

    @RequestMapping(value = "/version")
    def version() {
        "1.0.0"
    }

    @RequestMapping(value = "/categories", method = RequestMethod.POST)
    void create(@RequestBody Category category) {
        categoryService.create(category)
    }

    @RequestMapping(value = "/categories/{id}", method = RequestMethod.PUT)
    public void update(@PathVariable("id") int id, @RequestBody Category category) {
        category.setId(id);
        categoryService.update(category)
    }

    @RequestMapping(value = "/categories/{id}", method = RequestMethod.DELETE)
    public void deleteOne(@PathVariable("id") int id) {
        categoryService.deleteOne(id)
    }

    @RequestMapping(value = "/categories/{id}", method = RequestMethod.GET)
    public Category findOne(@PathVariable("id") int id) {
        categoryService.findOne(id)
    }

    @RequestMapping(value = "/categories", method = RequestMethod.GET)
    List<Category> findAll() {
        categoryService.findAll()
    }
}
