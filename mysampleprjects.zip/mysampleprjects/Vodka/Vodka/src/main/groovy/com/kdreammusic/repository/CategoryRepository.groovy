package com.kdreammusic.repository

import com.kdreammusic.model.Category
import org.springframework.data.jpa.repository.JpaRepository

interface CategoryRepository extends JpaRepository<Category, Integer> {

}