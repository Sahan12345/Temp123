package com.kdreammusic.service

import com.kdreammusic.model.Category

interface CategoryService {

    void create(Category category)

    void update(Category category)

    void deleteOne(int id)

    Category findOne(id);

    List<Category> findAll()
}