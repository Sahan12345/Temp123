package com.kdreammusic.service

import com.kdreammusic.repository.CategoryRepository
import com.kdreammusic.model.Category
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service("categoryService")
class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository

    @Override
    void create(Category category) {
        categoryRepository.save(category)
    }

    @Override
    void update(Category category) {
        categoryRepository.save(category)
    }

    @Override
    void deleteOne(int id) {
        categoryRepository.delete(id)
    }

    @Override
    Category findOne(Object id) {
        null
    }

    @Override
    List<Category> findAll() {
        categoryRepository.findAll()
    }
}
