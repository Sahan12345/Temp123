package com.packge.controller;

import com.packge.service.ServiceCls;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class ControllerCls1 {

    @Autowired
    private ServiceCls servicecls;

    @RequestMapping(value = "/",method=RequestMethod.GET)
    def getAllEmployees(){
        return  servicecls.getAllEmployees();
    }



}
