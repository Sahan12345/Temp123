package com.packge.dao

import com.packge.model.User
import org.springframework.stereotype.Repository

@Repository
class RepoCls {


    static map1  = [:]
    static{

        map1.put(1,new User(1, "man", "peninsula"));
        map1.put(2,new User(2, "man", "peninsula"));
        map1.put(3,new User(3, "man", "peninsula"));
    }

    def getAllEmployees(){
        return map1.values();
    }

}
