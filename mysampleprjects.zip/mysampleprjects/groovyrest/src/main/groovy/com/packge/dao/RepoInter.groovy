package com.packge.dao


interface RepoInter {

    def getAllEmployees();

}