package com.packge.model


class User {

    private def id;
    private def name;
    private def address;

    User(def id,def name,def address){
        this.id=id;
        this.name=name;
        this.address=address;
    }

    User(){};

    void setId(id) {
        this.id = id
    }

    void setName(name) {
        this.name = name
    }

    void setAddress(address) {
        this.address = address
    }

    def getId() {
        return id
    }

    def getName() {
        return name
    }

    def getAddress() {
        return address
    }

}
