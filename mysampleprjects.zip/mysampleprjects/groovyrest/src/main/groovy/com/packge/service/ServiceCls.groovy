package com.packge.service

import com.packge.dao.RepoCls
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ServiceCls {

    @Autowired
    private RepoCls repocls;

    def getAllEmployees(){
        return repocls.getAllEmployees();
    }

}
