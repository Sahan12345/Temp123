package com.pckg1.controller.Dao;

import com.pckg1.controller.Model.User;
import org.springframework.data.repository.CrudRepository;

import java.util.Collection;


public interface UserRepository extends CrudRepository<User, Integer> {

    User findById(int id);
    //User delete(int id);

}
